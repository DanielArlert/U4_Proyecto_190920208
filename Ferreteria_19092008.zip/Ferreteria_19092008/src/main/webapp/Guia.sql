USE FRT;

SELECT * FROM rol;

SELECT * FROM usuario;

SELECT * FROM cliente;

SELECT * FROM producto;

SELECT * FROM proveedor;

SELECT * FROM venta;

SELECT * FROM entrega;

SELECT * FROM detalle_venta;

SELECT * FROM detalle_entrega;


SELECT * FROM FolioVentaSiguiente;

    /*Se insertan los productos uno a uno para poder verificar el stock.*/
    INSERT INTO detalle_venta(folio_venta, id_producto, cantidad_pieza) VALUES  (2, 2, 1); 
    SELECT * FROM detalle_venta;
    SELECT * FROM producto;
        SELECT * FROM DetalleFacturaVentas;

    /*Se registra la segunda venta.*/
    INSERT INTO venta(folio_venta, id_cliente) VALUES (2, 2); 
    SELECT * FROM venta; 
        SELECT * FROM FacturaVentas;
    


SELECT * FROM FolioEntregaSiguiente;
    
    /*Se insertan los productos uno a uno para añadir al stock.*/                
    INSERT INTO detalle_entrega(folio_entrega, id_producto, cantidad_pieza) VALUES (2, 2, 75); 
    SELECT * FROM detalle_entrega;
    SELECT * FROM producto;
        SELECT * FROM DetalleFacturaEntregas;

    /*Se registra la segunda entrega.*/
    INSERT INTO entrega(folio_entrega, id_proveedor) VALUES (2, 2); 
    SELECT * FROM entrega;
        SELECT * FROM FacturaEntregas;
    


