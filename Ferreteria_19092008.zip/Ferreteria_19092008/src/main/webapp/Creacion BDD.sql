
CREATE DATABASE FRT;

USE FRT;

CREATE TABLE rol(	
    id_rol INT(5) NOT NULL AUTO_INCREMENT,	
    nombre_rol VARCHAR(20) NOT NULL,	
    CONSTRAINT id_rol PRIMARY KEY (id_rol)
);

CREATE TABLE usuario(	
    id_usuario INT(5) NOT NULL AUTO_INCREMENT,	
    usuario VARCHAR(20) NOT NULL UNIQUE,	
    clave VARCHAR(20) NOT NULL,	
    id_rol INT(5),	
    CONSTRAINT id_usuario PRIMARY KEY (id_usuario),	
    CONSTRAINT id_rol FOREIGN KEY (id_rol)
    REFERENCES rol (id_rol) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE cliente(	
    id_cliente INT(5) NOT NULL AUTO_INCREMENT,	
    nombre_cliente VARCHAR(20) NOT NULL,	
    apellidop_cliente VARCHAR(20) NOT NULL,	
    apellidom_cliente VARCHAR(20) NOT NULL,	
    calle VARCHAR(25) NOT NULL,	
    numero VARCHAR(5),	
    ciudad VARCHAR(20) NOT NULL,	
    telefono VARCHAR(10) UNIQUE,	
    CONSTRAINT cliente_key PRIMARY KEY (id_cliente)
);

CREATE TABLE producto(
    id_producto INT(5) NOT NULL AUTO_INCREMENT,
    nombre_producto VARCHAR(20) NOT NULL,
    precio_compra INT(5) NOT NULL,
    precio_venta INT(5) NOT NULL,
    marca VARCHAR(20),
    stock INT(5) NOT NULL,
    medidas VARCHAR(11),
    CONSTRAINT producto_key PRIMARY KEY (id_producto)
);

CREATE TABLE proveedor(	
    id_proveedor INT(5) NOT NULL auto_increment,
    nombre_proveedor VARCHAR(20) NOT NULL,
    apellidop_proveedor VARCHAR(20) NOT NULL,
    apellidom_proveedor VARCHAR(20) NOT NULL,
    correo VARCHAR(30) UNIQUE,
    CONSTRAINT proveedor_key PRIMARY KEY (id_proveedor)
);

CREATE TABLE venta(	
    folio_venta INT(5) NOT NULL auto_increment,	
    id_cliente INT(5) NOT NULL,	
    fecha timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,	
    total DOUBLE(8,2),	
    CONSTRAINT fventa_key PRIMARY KEY (folio_venta)
);

CREATE TABLE entrega(	
    folio_entrega INT(5) NOT NULL auto_increment,	
    id_proveedor INT(5) NOT NULL,	
    fecha timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,	
    total DOUBLE(8,2),	
    CONSTRAINT fentrega_key PRIMARY KEY (folio_entrega)
);

CREATE TABLE detalle_venta(
    folio_venta INT(5) NOT NULL,
    id_producto INT(5) NOT NULL,
    cantidad_pieza INT(5) NOT NULL,
    total_pieza DOUBLE(8,2)
);

CREATE TABLE detalle_entrega(	
    folio_entrega INT(5) NOT NULL,	
    id_producto INT(5) NOT NULL,	
    cantidad_pieza INT(5) NOT NULL,
    total_pieza DOUBLE(8,2)
);



INSERT INTO rol(nombre_rol) VALUES		
    ('Maestro'),	
    ('Almacenista'),
    ('Cajero'),		
    ('Gerente');

INSERT INTO usuario(usuario, clave, id_rol) VALUES	
    ('maestro', '19092000', 1),	
    ('almacenista', '19092010', 2),	
    ('cajero', '19092020', 3),	
    ('gerete', '19092030', 4);


INSERT INTO cliente(nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono) VALUES
    ('Roberto', 'Arlt', 'Laiseca', 'Matamoros', '15', 'Patzcuaro', '4349007086'),
    ('Ricardo', 'Piglia', 'Cohen', 'Guerrero', '25', 'Quiroga', '4346451653'),
    ('Ernesto', 'Sabato', 'Alamada', 'Mina', '35', 'Tzintzuntzan', '4342676341'),
    ('Leopoldo', 'Lugones', 'Harwicz', 'Bravo', '45', 'Morelia', '4346549462'),
    ('Silvina', 'Ocampo', 'Mairal', 'Aldama', '55', 'Patzcuaro', '4344019533'),
    ('Ariana', 'Harwicz', 'Lugones', 'Victoria', '15', 'Quiroga', '4346866870'),
    ('Pedro', 'Mairal', 'Ocampo', 'Galeana', '25', 'Tzintzuntzan', '4344570907'),
    ('Selva', 'Alamada', 'Sabato', 'Iturbide', '35', 'Morelia', '4349419851'),
    ('Marcelo', 'Cohen', 'Piglia', 'Torres', '45', 'Tzintzuntzan', '4345200080'),
    ('Alberto', 'Laiseca', 'Arlt', 'Bustamante', '55', 'Patzcuaro', '4344772750');


INSERT INTO producto(nombre_producto, precio_compra, precio_venta, marca, stock, medidas) VALUES
    ('Martillo', 50, 100, 'Truper', 75, '25'),
    ('Cinta metrica', 75, 150, 'Stanley', 75, '100m'),
    ('Broca HSS', 30, 60, 'Toolcraft', 75, '5'),
    ('Alambre galvanizado', 75, 150, 'Toolcraft', 75, '150m'),
    ('Clavo', 1, 5, 'Fifa', 5000, '2'),
    ('Tornillo de madera', 1, 5, 'Veker', 5000, '10x2'),
    ('Tornillo 6', 1, 5, 'Veker', 5000, '5/8'),
    ('Rondana con neopreo', 1, 5, 'Celta', 5000, '1/4x5/8'),
    ('Grapa recta de cable', 1, 5, 'Fulgore', 5000, '10'),
    ('Pasador mauser', 1, 5, 'Carpi', 5000, '25');


INSERT INTO proveedor(nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo) VALUES
    ('Stephen', 'King', 'Machado', 'sking@gmail.com'),
    ('Julio', 'Cortazar', 'Alas', 'jcortazar@gmail.com'),
    ('Julio', 'Verne', 'AleixANDre', 'jverne@gmail.com'),
    ('Antonio', 'Machado', 'Altolaguirre', 'amachado@gmail.com'),
    ('Francisco', 'Ayala', 'Verne', 'fayala@gmail.com'),
    ('Vicente', 'AleixANDre', 'Leon', 'valeixANDre@gmail.com'),
    ('Manuel', 'Altolaguirre', 'Ayala', 'mltolaguirre@gmail.com'),
    ('Leopoldo', 'Alas', 'Rosa', 'lalas@gmail.com'),
    ('Rafael', 'Alberti', 'King', 'ralberti@gmail.com'),
    ('Jose', 'Machado', 'Cortazar', 'jamachado@gmail.com');


INSERT INTO venta(folio_venta, id_cliente, total) VALUES 
    (1, 1, 310);


INSERT INTO entrega(folio_entrega, id_proveedor, total) VALUES 
    (1, 1, 2500);


INSERT INTO detalle_venta(folio_venta, id_producto, cantidad_pieza, total_pieza) VALUES 
    (1, 1, 1, 100),
    (1, 2, 1, 150),
    (1, 3, 1, 60);


INSERT INTO detalle_entrega(folio_entrega, id_producto, cantidad_pieza, total_pieza) VALUES 
    (1, 1, 50, 2500);



CREATE VIEW FacturaVentas AS 
SELECT folio_venta, cli.id_cliente, nombre_cliente, apellidop_cliente, apellidom_cliente, total, fecha 
FROM (SELECT * FROM venta) AS ven,
	(SELECT id_cliente, nombre_cliente, apellidop_cliente, apellidom_cliente FROM cliente) AS cli
WHERE ven.id_cliente=cli.id_cliente;
    

DELIMITER $$
CREATE TRIGGER registro_venta BEFORE INSERT ON venta
FOR EACH ROW BEGIN

    IF(NEW.id_cliente>0) THEN	
        SET NEW.total = (SELECT SUM(total_pieza) FROM detalle_venta WHERE folio_venta = NEW.folio_venta);		
    END IF;
                        
END $$
DELIMITER ;


CREATE VIEW FolioVentaSiguiente AS SELECT (MAX(folio_venta)+1) AS FVS FROM venta;


            CREATE VIEW DetalleFacturaVentas AS  
            SELECT venta.folio_venta, nombre_producto, det.cantidad_pieza, det.total_pieza, fecha 
            FROM (SELECT id_producto, nombre_producto FROM producto) AS pro,
                    (SELECT * FROM detalle_venta) AS det,
                    (SELECT * FROM venta) AS venta,
                    (SELECT id_cliente FROM cliente) AS cli 
            WHERE pro.id_producto=det.id_producto AND venta.folio_venta=det.folio_venta AND venta.id_cliente=cli.id_cliente;


            DELIMITER $$
            CREATE TRIGGER registro_det_venta BEFORE INSERT ON detalle_venta
            FOR EACH ROW BEGIN

                IF(NEW.cantidad_pieza>0) THEN	

                    SET NEW.total_pieza = (SELECT precio_venta FROM producto WHERE id_producto = NEW.id_producto) * NEW.cantidad_pieza;

                    UPDATE producto 
                        SET producto.stock = (SELECT stock WHERE id_producto = NEW.id_producto) 
                        - NEW.cantidad_pieza WHERE id_producto = NEW.id_producto;
                END IF;

            END $$
            DELIMITER ;



CREATE VIEW FacturaEntregas AS  
SELECT folio_entrega, prov.id_proveedor, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, total, fecha 
FROM (SELECT * FROM entrega) AS ent,
	(SELECT id_proveedor, nombre_proveedor, apellidop_proveedor, apellidom_proveedor FROM proveedor) AS prov
WHERE ent.id_proveedor=prov.id_proveedor;


DELIMITER $$
CREATE TRIGGER registro_entrega BEFORE INSERT ON entrega
FOR EACH ROW BEGIN

    IF(NEW.id_proveedor>0) THEN	
        SET NEW.total =  (SELECT SUM(total_pieza) FROM detalle_entrega WHERE folio_entrega = NEW.folio_entrega);	
    END IF;
                        
END $$
DELIMITER ;


CREATE VIEW FolioEntregaSiguiente AS SELECT (MAX(folio_entrega)+1) AS FES FROM entrega;


            CREATE VIEW DetalleFacturaEntregas AS 
            SELECT entrega.folio_entrega, nombre_producto, det.cantidad_pieza, det.total_pieza, fecha 
            FROM (SELECT id_producto, nombre_producto FROM producto) AS pro,
                    (SELECT * FROM detalle_entrega) AS det,
                    (SELECT * FROM entrega) AS entrega,
                    (SELECT id_proveedor FROM proveedor) AS prov
            WHERE pro.id_producto=det.id_producto AND entrega.folio_entrega=det.folio_entrega AND entrega.id_proveedor=prov.id_proveedor;


            DELIMITER $$
            CREATE TRIGGER registro_det_entrega BEFORE INSERT ON detalle_entrega
            FOR EACH ROW BEGIN

                IF(NEW.cantidad_pieza>0) THEN	

                    SET NEW.total_pieza = (SELECT precio_venta FROM producto WHERE id_producto = NEW.id_producto) * NEW.cantidad_pieza;

                    UPDATE producto 
                        SET producto.stock = (SELECT stock WHERE id_producto = NEW.id_producto) 
                        + NEW.cantidad_pieza WHERE id_producto = NEW.id_producto;
                END IF;

            END $$
            DELIMITER ;