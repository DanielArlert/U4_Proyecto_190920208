package mx.edu.itspa.controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.general.Usuario;
import mx.edu.itspa.modelo.UsuarioDAO;

public class UsuarioServlet extends HttpServlet {
    
    UsuarioDAO UDAO = new UsuarioDAO();
    Usuario US = new Usuario();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        String accion = request.getParameter("accion");
        
        if (accion.equalsIgnoreCase("Ingresar")) {
            String usuario = request.getParameter("usuario");
            String clave = request.getParameter("clave");
            
            US = UDAO.Validar(usuario, clave);
            
            if (US.getUsuario() != null) {
                
                if( US.getNombre_rol().equals("Almacenista") ){
                    request.getRequestDispatcher("AlmacenistaServlet?menu=Almacenista").forward(request, response);
                } else if( US.getNombre_rol().equals("Cajero") ){
                    request.getRequestDispatcher("CajeroServlet?menu=Cajero").forward(request, response);
                }
                
            } else {
                request.getRequestDispatcher("Acceso?menu=Salir").forward(request, response);
            }            
        } else {
            request.getRequestDispatcher("Acceso?menu=Salir").forward(request, response);
        } 
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
