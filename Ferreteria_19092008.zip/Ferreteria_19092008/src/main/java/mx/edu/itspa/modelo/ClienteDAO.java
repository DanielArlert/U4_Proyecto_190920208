package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Cliente;

public class ClienteDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List listar(){
        String SELECT_ALL_CLIENTE = "select * from cliente";
            
        List<Cliente> lista_cliente = new ArrayList();
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_CLIENTE);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Cliente cli = new Cliente();
                
                cli.setId_cliente(rs.getInt(1));
                cli.setNombre_cliente(rs.getString(2));
                cli.setApellidop_cliente(rs.getString(3));
                cli.setApellidom_cliente(rs.getString(4));
                cli.setCalle(rs.getString(5));
                cli.setNumero(rs.getString(6));
                cli.setCiudad(rs.getString(7));
                cli.setTelefono(rs.getString(8));
                  
                lista_cliente.add(cli);
            }            
            
        } catch (Exception e){
            
        }
        return lista_cliente;
    }
    
    
    public int Agregar(Cliente c){
        String INSERT_CLIENTE = "insert into cliente(nombre_cliente, apellidop_cliente, "
                + "apellidom_cliente, calle, numero, ciudad, telefono) values(?, ?, ?, ?, ?, ?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CLIENTE);
            
            preparedStatement.setString(1, c.getNombre_cliente());
            preparedStatement.setString(2, c.getApellidop_cliente());
            preparedStatement.setString(3, c.getApellidom_cliente());
            preparedStatement.setString(4, c.getCalle());
            preparedStatement.setString(5, c.getNumero());
            preparedStatement.setString(6, c.getCiudad());
            preparedStatement.setString(7, c.getTelefono());

                preparedStatement.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public int Actualizar(Cliente c){
        String UPDATE_CLIENTE = "update cliente set nombre_cliente=?, apellidop_cliente=?, "
                + "apellidom_cliente=?, calle=?, numero=?, ciudad=?, telefono=? where id_cliente=?";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLIENTE);
            
            preparedStatement.setString(1, c.getNombre_cliente());
            preparedStatement.setString(2, c.getApellidop_cliente());
            preparedStatement.setString(3, c.getApellidom_cliente());
            preparedStatement.setString(4, c.getCalle());
            preparedStatement.setString(5, c.getNumero());
            preparedStatement.setString(6, c.getCiudad());
            preparedStatement.setString(7, c.getTelefono());
            preparedStatement.setInt(8, c.getId_cliente());

                preparedStatement.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public void Eliminar(int id_cliente){
        String DELETE_CLIENTE = "delete from cliente where id_cliente="+id_cliente;
                
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLIENTE);
            
            preparedStatement.executeUpdate();
                
        } catch(Exception e){ }
        
    }
    
    
    public Cliente ListarPorId(int id_cliente){
        String SELECT_CLIENTE_ID = "select * from cliente where id_cliente="+id_cliente;
        
        Cliente cli = new Cliente();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_CLIENTE_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                    cli.setNombre_cliente(rs.getString(2));
                    cli.setApellidop_cliente(rs.getString(3));
                    cli.setApellidom_cliente(rs.getString(4));
                    cli.setCalle(rs.getString(5));
                    cli.setNumero(rs.getString(6));
                    cli.setCiudad(rs.getString(7));
                    cli.setTelefono(rs.getString(8));            

                    ps.executeUpdate();
                }
                
        } catch(Exception e){ }
        
        return cli;
    }
    
    
    public Cliente ListarPorIdConId(int id_cliente){
        String SELECT_CLIENTE_ID = "select * from cliente where id_cliente="+id_cliente;
        
        Cliente cli = new Cliente();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_CLIENTE_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                    cli.setId_cliente(rs.getInt(1));
                    cli.setNombre_cliente(rs.getString(2));
                    cli.setApellidop_cliente(rs.getString(3));
                    cli.setApellidom_cliente(rs.getString(4));
                    cli.setCalle(rs.getString(5));
                    cli.setNumero(rs.getString(6));
                    cli.setCiudad(rs.getString(7));
                    cli.setTelefono(rs.getString(8));            

                    ps.executeUpdate();
                }
                
        } catch(Exception e){ }
        
        return cli;
    }
    
}
