package mx.edu.itspa.general;

public class DetalleVenta extends Venta{
    int id_producto;
    String nombre_producto;
    int cantidad_pieza;
    double total_pieza;

    public DetalleVenta( ) { }

    public DetalleVenta(String nombre_producto, int cantidad_pieza, double total_pieza, int folio_venta, int id_cliente, String fecha, double total, String nombre_cliente, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono) {
        super(folio_venta, id_cliente, fecha, total, nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
        this.nombre_producto = nombre_producto;
        this.cantidad_pieza = cantidad_pieza;
        this.total_pieza = total_pieza;
    }

    public String getNombre_producto() { return nombre_producto; }
    public void setNombre_producto(String nombre_producto) { this.nombre_producto = nombre_producto; }

        public int getCantidad_pieza() { return cantidad_pieza; }
        public void setCantidad_pieza(int cantidad_pieza) { this.cantidad_pieza = cantidad_pieza; }

    public double getTotal_pieza() { return total_pieza; }
    public void setTotal_pieza(double total_pieza) { this.total_pieza = total_pieza; }

        public int getId_producto() { return id_producto; }
        public void setId_producto(int id_producto) { this.id_producto = id_producto; }
}
