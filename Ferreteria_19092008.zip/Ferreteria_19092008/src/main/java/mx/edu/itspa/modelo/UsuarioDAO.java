package mx.edu.itspa.modelo;

import mx.edu.itspa.general.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public Usuario Validar(String usuario, String clave){
        Usuario US = new Usuario();
        String SELECT_USER = "select r.id_rol, r.nombre_rol, us.usuario, us.clave from usuario us inner join rol r on r.id_rol = us.id_rol where us.usuario=? and us.clave=?";
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement PS = connection.prepareStatement(SELECT_USER);
            ResultSet RS;
            
            PS.setString(1, usuario);
            PS.setString(2, clave);
            
            RS = PS.executeQuery();
            
            

            while (RS.next()) {
                US.setId_rol(RS.getInt("id_rol"));
                US.setNombre_rol(RS.getString("nombre_rol"));
                US.setUsuario(RS.getString("usuario"));
                US.setClave(RS.getString("clave"));
            }
        }catch(Exception e){    }
        
        return US;
    }
            
}
