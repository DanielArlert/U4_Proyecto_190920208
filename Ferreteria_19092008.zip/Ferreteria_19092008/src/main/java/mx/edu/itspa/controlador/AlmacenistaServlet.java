package mx.edu.itspa.controlador;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.general.DetalleEntrega;
import mx.edu.itspa.general.Entrega;
import mx.edu.itspa.general.Producto;
import mx.edu.itspa.modelo.ProductoDAO;
import mx.edu.itspa.general.Proveedor;
import mx.edu.itspa.modelo.DetalleEntregaDAO;
import mx.edu.itspa.modelo.EntregaDAO;
import mx.edu.itspa.modelo.ProveedorDAO;

public class AlmacenistaServlet extends HttpServlet {

    Producto producto = new Producto();
    ProductoDAO PDAO = new ProductoDAO();
    int id_producto;

    Proveedor proveedor = new Proveedor();
    ProveedorDAO PRDAO = new ProveedorDAO();
    int id_proveedor;
    
    int folio_entrega;
    Entrega entrega = new Entrega();
    EntregaDAO EDAO = new EntregaDAO();
    
    DetalleEntrega d_entrega = new DetalleEntrega();
    DetalleEntregaDAO DEDAO = new DetalleEntregaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String menu = request.getParameter("menu");
        
            if(menu.equals("Almacenista")){
                List listado = EDAO.ListarEntregas();
                request.setAttribute("facturaentrega", listado);
                request.getRequestDispatcher("Vista/Almacenista/Almacenista.jsp").forward(request, response);
            }         
        
            if(menu.equals("AlmacenistaObtenerDetalle")){
                folio_entrega = Integer.parseInt(request.getParameter("folio_entrega"));
                List DE = DEDAO.ListarPorId(folio_entrega);
                
                request.setAttribute("detallefacturaentrega", DE);
                request.getRequestDispatcher("AlmacenistaServlet?menu=Almacenista").forward(request, response);
            }                
            
            
            
            
            
            if(menu.equals("AlmacenistaSelectProveedores")){
                List lista_proveedores = PRDAO.listar();
                request.setAttribute("proveedores", lista_proveedores);
                request.getRequestDispatcher("Vista/Almacenista/Proveedores.jsp").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaInsertProveedores")){
                String np = request.getParameter("nombre_proveedor");
                String app = request.getParameter("apellidop_proveedor");
                String amp = request.getParameter("apellidom_proveedor");
                String email = request.getParameter("correo");
                            
                proveedor.setNombre_proveedor(np);
                proveedor.setApellidop_proveedor(app);
                proveedor.setApellidom_proveedor(amp);
                proveedor.setCorreo(email);
                
                PRDAO.Agregar(proveedor);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaIdentifierProveedores")){
                id_proveedor=Integer.parseInt(request.getParameter("id_proveedor"));
                Proveedor PR = PRDAO.ListarPorId(id_proveedor);
                        
                request.setAttribute("pr", PR);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaUpdateProveedores")){
                String np2 = request.getParameter("nombre_proveedor");
                String app2 = request.getParameter("apellidop_proveedor");
                String amp2 = request.getParameter("apellidom_proveedor");
                String email2 = request.getParameter("correo");
                            
                proveedor.setNombre_proveedor(np2);
                proveedor.setApellidop_proveedor(app2);
                proveedor.setApellidom_proveedor(amp2);
                proveedor.setCorreo(email2);
                
                proveedor.setId_proveedor(id_proveedor);
                
                PRDAO.Actualizar(proveedor);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaDeleteProveedores")){
                id_proveedor=Integer.parseInt(request.getParameter("id_proveedor"));
                PRDAO.Eliminar(id_proveedor);
                        
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            } 
            
             
            
            
            
            if(menu.equals("AlmacenistaSelectProductos")){
                List lista_productos = PDAO.listar();
                request.setAttribute("productos", lista_productos);
                request.getRequestDispatcher("Vista/Almacenista/Productos.jsp").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaInsertProductos")){
                String np = request.getParameter("nombre_producto");
                int pc = Integer.parseInt(request.getParameter("precio_compra"));
                int pv = Integer.parseInt(request.getParameter("precio_venta"));
                String m = request.getParameter("marca");
                int stk = Integer.parseInt(request.getParameter("stock"));
                String mds = request.getParameter("medidas");
                
                producto.setNombre_producto(np);
                producto.setPrecio_compra(pc);
                producto.setPrecio_venta(pv);
                producto.setMarca(m);
                producto.setStock(stk);
                producto.setMedidas(mds);
                
                PDAO.Agregar(producto);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaIdentifierProductos")){
                id_producto=Integer.parseInt(request.getParameter("id_producto"));
                Producto P = PDAO.ListarPorId(id_producto);
                        
                request.setAttribute("p", P);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaUpdateProductos")){
                String np2 = request.getParameter("nombre_producto");
                int pc2 = Integer.parseInt(request.getParameter("precio_compra"));
                int pv2 = Integer.parseInt(request.getParameter("precio_venta"));
                String m2 = request.getParameter("marca");
                int stk2 = Integer.parseInt(request.getParameter("stock"));
                String mds2 = request.getParameter("medidas");
                
                producto.setNombre_producto(np2);
                producto.setPrecio_compra(pc2);
                producto.setPrecio_venta(pv2);
                producto.setMarca(m2);
                producto.setStock(stk2);
                producto.setMedidas(mds2);
                
                producto.setId_producto(id_producto);
                
                PDAO.Actualizar(producto);
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaDeleteProductos")){
                id_producto=Integer.parseInt(request.getParameter("id_producto"));
                PDAO.Eliminar(id_producto);
                        
                request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("AlmacenistaFacturarEntrega")){
                int next_e = EDAO.ProximaFacturaEntrega();
                request.setAttribute("prx", next_e);
                
                request.getRequestDispatcher("Vista/Almacenista/FacturarEntrega.jsp").forward(request, response);
            } 
            
                if(menu.equals("AlmacenistaFacturarEntregaIdProducto")){
                    id_producto=Integer.parseInt(request.getParameter("id_producto"));
                    Producto P = PDAO.ListarPorIdConId(id_producto);

                    request.setAttribute("pfe", P);
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 

                if(menu.equals("AlmacenistaFacturarEntregaIdProveedor")){
                    id_proveedor=Integer.parseInt(request.getParameter("id_proveedor"));
                    Proveedor P = PRDAO.ListarPorIdConId(id_proveedor);

                    request.setAttribute("prfe", P);
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaFacturarEntregaIngresarProducto")){
                    int fe = Integer.parseInt(request.getParameter("folio_entrega"));
                    int ip = Integer.parseInt(request.getParameter("id_producto"));
                    int can = Integer.parseInt(request.getParameter("cantidad_pieza"));
                    
                    d_entrega.setFolio_entrega(fe);
                    d_entrega.setId_producto(ip);
                    d_entrega.setCantidad_pieza(can);
                    
                    DEDAO.Agregar(d_entrega);
                    
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaFacturar")){
                    int fef = Integer.parseInt(request.getParameter("folio_entrega"));
                    int ipf = Integer.parseInt(request.getParameter("id_proveedor"));
                    
                    entrega.setFolio_entrega(fef);
                    entrega.setId_proveedor(ipf);
                        EDAO.Agregar(entrega);
                
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaComprobante").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaComprobante")){
                    int fef = Integer.parseInt(request.getParameter("folio_entrega"));     
                    int ipf = Integer.parseInt(request.getParameter("id_proveedor"));   
                        
                    int x = fef;
                        List DE = DEDAO.ListarPorId(x);
                        request.setAttribute("DE", DE);
                        request.setAttribute("folio", x);
                        
                    Entrega propietario = EDAO.ListarEntregasPorId(fef);
                    request.setAttribute("p_ent", propietario);
                    
                    Proveedor PRO = PRDAO.ListarPorId(ipf);
                    request.setAttribute("pr", PRO);
                
                request.getRequestDispatcher("Vista/Almacenista/AFactura.jsp").forward(request, response);
                } 
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
