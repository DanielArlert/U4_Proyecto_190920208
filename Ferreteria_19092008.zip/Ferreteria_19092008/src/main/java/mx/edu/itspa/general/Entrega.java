package mx.edu.itspa.general;

public class Entrega extends Proveedor{
    int folio_entrega;
    int id_proveedor;
    String fecha;
    double total;

    public Entrega() {    }
   
    public Entrega(int folio_entrega, int id_proveedor) {
        this.folio_entrega = folio_entrega;
        this.id_proveedor = id_proveedor;
    }

    public Entrega(int folio_entrega, int id_proveedor, String fecha, double total, String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo) {
        super(id_proveedor, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
        this.folio_entrega = folio_entrega;
        this.fecha = fecha;
        this.total = total;
    }

    public int getFolio_entrega() { return folio_entrega; }
    public void setFolio_entrega(int folio_entrega) { this.folio_entrega = folio_entrega; }

        public int getId_proveedor() { return id_proveedor; }
        public void setId_proveedor(int id_proveedor) { this.id_proveedor = id_proveedor; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

        public double getTotal() { return total; }
        public void setTotal(double total) { this.total = total; }
}
