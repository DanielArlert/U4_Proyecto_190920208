package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.DetalleVenta;

public class DetalleVentaDAO {
    Conexion connect = new Conexion();
    int r;
        
    
    public List ListarDetalleFacturaVenta(){
        String SELECT_ALL_VENTA = "select * from DetalleFacturaVentas";
            
        List<DetalleVenta> lista_dventa = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_VENTA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                DetalleVenta dventa = new DetalleVenta();
                
                dventa.setFolio_venta(rs.getInt(1));
                dventa.setNombre_producto(rs.getString(2));
                dventa.setCantidad_pieza(rs.getInt(3));
                dventa.setTotal_pieza(rs.getDouble(4));
                dventa.setFecha(rs.getString(5));
                  
                lista_dventa.add(dventa);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_dventa;
    }
  
    
    public List ListarPorId(int folio_venta){
        String SELECT_DETALLE = "select * from DetalleFacturaVentas where folio_venta="+folio_venta;
            
        List<DetalleVenta> lista_dventa = new ArrayList();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_DETALLE);
            ResultSet rs = ps.executeQuery();
                
            while(rs.next()){
                DetalleVenta dventa = new DetalleVenta();
                
                dventa.setFolio_venta(rs.getInt(1));
                dventa.setNombre_producto(rs.getString(2));
                dventa.setCantidad_pieza(rs.getInt(3));
                dventa.setTotal_pieza(rs.getDouble(4));
                dventa.setFecha(rs.getString(5));   
                
                lista_dventa.add(dventa);
            }
                
        } catch(Exception e){ }
        
        return lista_dventa;
    }
    
    
    public int Agregar(DetalleVenta dventa){
        String INSERT_DETALLE_VENTA = "insert into detalle_venta(folio_venta, id_producto, cantidad_pieza) values(?, ?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_DETALLE_VENTA);
            
            ps.setInt(1, dventa.getFolio_venta());
            ps.setInt(2, dventa.getId_producto());
            ps.setInt(3, dventa.getCantidad_pieza());

            ps.executeUpdate();
                
        } catch(SQLException e){ }
        
        return r;
    }
    
}
