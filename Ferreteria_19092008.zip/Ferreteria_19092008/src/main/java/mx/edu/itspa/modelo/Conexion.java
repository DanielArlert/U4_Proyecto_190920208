package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private String database = "jdbc:mysql://localhost:3306/FRT?serverTimezone=UTC";
    private String usuario = "root";
    private String clave = "root";
    int r;
    
    public Connection Conectar() {
        Connection connection = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(database, usuario, clave);
                //System.out.println("Conexión realizada.");
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } 
        return connection;
    }
}
