package mx.edu.itspa.controlador;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.general.Cliente;
import mx.edu.itspa.general.DetalleVenta;
import mx.edu.itspa.modelo.ClienteDAO;
import mx.edu.itspa.general.Producto;
import mx.edu.itspa.general.Venta;
import mx.edu.itspa.modelo.DetalleVentaDAO;
import mx.edu.itspa.modelo.ProductoDAO;
import mx.edu.itspa.modelo.VentaDAO;

public class CajeroServlet extends HttpServlet {

    Producto producto = new Producto();
    ProductoDAO PDAO = new ProductoDAO();
    int id_producto;

    Cliente cliente = new Cliente();
    ClienteDAO CDAO = new ClienteDAO();
    ClienteDAO CDAOO = new ClienteDAO();
    int id_cliente;
    
    Venta venta = new Venta();
    VentaDAO VDAO = new VentaDAO();
    
    int folio_venta;
    DetalleVenta d_venta = new DetalleVenta();
    DetalleVentaDAO DVDAO = new DetalleVentaDAO();
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String menu = request.getParameter("menu");
        
            if(menu.equals("Cajero")){
                List listado = VDAO.ListarVentas();
                request.setAttribute("facturaventa", listado);
                request.getRequestDispatcher("Vista/Cajero/Cajero.jsp").forward(request, response);
            }
            
            if(menu.equals("CajeroObtenerDetalle")){
                folio_venta = Integer.parseInt(request.getParameter("folio_venta"));
                List DV = DVDAO.ListarPorId(folio_venta);
                
                request.setAttribute("detallefacturaventa", DV);
                request.getRequestDispatcher("CajeroServlet?menu=Cajero").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("CajeroSelectClientes")){
                List lista = CDAO.listar();
                request.setAttribute("clientes", lista);
                request.getRequestDispatcher("Vista/Cajero/Clientes.jsp").forward(request, response);
            } 
            
            if(menu.equals("CajeroInsertClientes")){
                String nombre_cliente = request.getParameter("nombre_cliente");
                String apellidop_cliente = request.getParameter("apellidop_cliente");
                String apellidom_cliente = request.getParameter("apellidom_cliente");
                String calle = request.getParameter("calle");
                String numero = request.getParameter("numero");
                String ciudad = request.getParameter("ciudad");
                String telefono = request.getParameter("telefono");
                            
                cliente.setNombre_cliente(nombre_cliente);
                cliente.setApellidop_cliente(apellidop_cliente);
                cliente.setApellidom_cliente(apellidom_cliente);
                cliente.setCalle(calle);
                cliente.setNumero(numero);
                cliente.setCiudad(ciudad);
                cliente.setTelefono(telefono);
                
                CDAO.Agregar(cliente);
                request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            } 
            
            if(menu.equals("CajeroIdentifierClientes")){
                id_cliente=Integer.parseInt(request.getParameter("id_cliente"));
                Cliente C = CDAO.ListarPorId(id_cliente);
                        
                request.setAttribute("c", C);
                request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            } 
            
            if(menu.equals("CajeroUpdateClientes")){
                String nombre_cliente2 = request.getParameter("nombre_cliente");
                String apellidop_cliente2 = request.getParameter("apellidop_cliente");
                String apellidom_cliente2 = request.getParameter("apellidom_cliente");
                String calle2 = request.getParameter("calle");
                String numero2 = request.getParameter("numero");
                String ciudad2 = request.getParameter("ciudad");
                String telefono2 = request.getParameter("telefono");
                
                cliente.setNombre_cliente(nombre_cliente2);
                cliente.setApellidop_cliente(apellidop_cliente2);
                cliente.setApellidom_cliente(apellidom_cliente2);
                cliente.setCalle(calle2);
                cliente.setNumero(numero2);
                cliente.setCiudad(ciudad2);
                cliente.setTelefono(telefono2);
                
                cliente.setId_cliente(id_cliente);
                            
                
                CDAO.Actualizar(cliente);
                request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            } 
            
            if(menu.equals("CajeroDeleteClientes")){
                id_cliente=Integer.parseInt(request.getParameter("id_cliente"));
                CDAO.Eliminar(id_cliente);
                        
                request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("CajeroSelectProductos")){
                List lista_productos = PDAO.listar();
                request.setAttribute("productoscajero", lista_productos);
                request.getRequestDispatcher("Vista/Cajero/Productos.jsp").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("CajeroFacturarVenta")){
                int next_v = VDAO.ProximaFacturaVenta();
                    
                request.setAttribute("prx", next_v);
                request.getRequestDispatcher("Vista/Cajero/FacturarVenta.jsp").forward(request, response);
            } 
            
                if(menu.equals("CajeroFacturarVentaIdProducto")){
                    id_producto=Integer.parseInt(request.getParameter("id_producto"));
                    Producto P = PDAO.ListarPorIdConId(id_producto);

                    request.setAttribute("pfv", P);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 

                if(menu.equals("CajeroFacturarVentaIdCliente")){
                    id_cliente=Integer.parseInt(request.getParameter("id_cliente"));
                    Cliente C = CDAO.ListarPorIdConId(id_cliente);

                    request.setAttribute("cfv", C);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 
            
                if(menu.equals("CajeroFacturaVentaIngresarProducto")){
                    int fv = Integer.parseInt(request.getParameter("folio_venta"));
                    int ip = Integer.parseInt(request.getParameter("id_producto"));
                    int can = Integer.parseInt(request.getParameter("cantidad_pieza"));
                    
                    d_venta.setFolio_venta(fv);
                    d_venta.setId_producto(ip);
                    d_venta.setCantidad_pieza(can);
                    
                    DVDAO.Agregar(d_venta);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 
            
                if(menu.equals("CajeroFacturar")){
                    int fvf = Integer.parseInt(request.getParameter("folio_venta"));
                    int icf = Integer.parseInt(request.getParameter("id_cliente")); 
                    
                    venta.setFolio_venta(fvf);
                    venta.setId_cliente(icf);
                        VDAO.Agregar(venta);
                    
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroComprobante").forward(request, response);
                } 
            
                if(menu.equals("CajeroComprobante")){
                    int fvf = Integer.parseInt(request.getParameter("folio_venta"));    
                    int icf = Integer.parseInt(request.getParameter("id_cliente"));  
                    
                    int x = fvf;
                        List DV = DVDAO.ListarPorId(x);
                        request.setAttribute("DV", DV);
                        request.setAttribute("folio", x);                                             
                        
                    Venta propietario = VDAO.ListarVentasPorId(fvf);
                    request.setAttribute("p_ven", propietario);
                                        
                    Cliente CLI = CDAO.ListarPorId(icf);
                    request.setAttribute("c", CLI);
                
                request.getRequestDispatcher("Vista/Cajero/CFactura.jsp").forward(request, response);
                }         
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
