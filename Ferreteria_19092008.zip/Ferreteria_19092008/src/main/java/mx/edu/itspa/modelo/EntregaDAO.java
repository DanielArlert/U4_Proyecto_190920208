package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Entrega;

public class EntregaDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List ListarFacturaEntrega(){
        String SELECT_ALL_ENTREGA = "select * from FacturaEntregas";
            
        List<Entrega> lista_entrega = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_ENTREGA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Entrega entrega = new Entrega();
                
                entrega.setFolio_entrega(rs.getInt(1));
                entrega.setNombre_proveedor(rs.getString(2));
                entrega.setApellidop_proveedor(rs.getString(3));
                entrega.setApellidom_proveedor(rs.getString(4));
                entrega.setTotal(rs.getDouble(5));
                entrega.setFecha(rs.getString(6));
                  
                lista_entrega.add(entrega);
            }            
            
        } catch (Exception e){ }
        
        return lista_entrega;
    }
    
    
    public int ProximaFacturaEntrega(){
        String SELECT_SIG_ENTREGA = "select * from FolioEntregaSiguiente";
            
        Entrega venta = new Entrega();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_SIG_ENTREGA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                venta.setFolio_entrega(rs.getInt(1));

                ps.executeUpdate();                
            }   
            
        } catch (Exception e){ }
        
        return venta.getFolio_entrega();
    }
    
    
    public Entrega ListarEntregasPorId(int folio_entrega){
        String SELECT_FOLIO_ID = "select * from FacturaEntregas where folio_entrega="+folio_entrega;
        
        Entrega entrega = new Entrega();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_FOLIO_ID);
            ResultSet rs = ps.executeQuery();
                
            while(rs.next()){
                entrega.setFolio_entrega(rs.getInt(1));
                entrega.setId_proveedor(rs.getInt(2));
                entrega.setNombre_proveedor(rs.getString(3));
                entrega.setApellidop_proveedor(rs.getString(4));
                entrega.setApellidom_proveedor(rs.getString(5));
                entrega.setTotal(rs.getDouble(6));
                entrega.setFecha(rs.getString(7)); 
                
                    ps.executeUpdate();
            }
                
        } catch(Exception e){ }
        
        return entrega;
    }
    
    
    public List ListarEntregas(){
        String SELECT_FE = "select * from FacturaEntregas";
        
        List<Entrega> lista_entrega = new ArrayList();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_FE);
            ResultSet rs = ps.executeQuery();
                
            while(rs.next()){
                Entrega entrega = new Entrega(); 
        
                entrega.setFolio_entrega(rs.getInt(1));
                entrega.setId_proveedor(rs.getInt(2));
                entrega.setNombre_proveedor(rs.getString(3));
                entrega.setApellidop_proveedor(rs.getString(4));
                entrega.setApellidom_proveedor(rs.getString(5));
                entrega.setTotal(rs.getDouble(6));
                entrega.setFecha(rs.getString(7)); 
                
                lista_entrega.add(entrega);
            }
                
        } catch(Exception e){ }
        
        return lista_entrega;
    }
    
    
    public int Agregar(Entrega ent){
        String INSERT_ENTREGA = "insert into entrega(folio_entrega, id_proveedor) values(?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_ENTREGA);
            
            ps.setInt(1, ent.getFolio_entrega());
            ps.setInt(2, ent.getId_proveedor());

            ps.executeUpdate();
                
        } catch(SQLException e){ }
        
        return r;
    }
    
}
