package mx.edu.itspa.general;

public class Venta extends Cliente{    
    int folio_venta;
    int id_cliente;
    String fecha;
    double total;

    public Venta(){ }
    
    public Venta(int folio_venta) {
        this.folio_venta = folio_venta;
    }
    
    public Venta(int folio_venta, int id_cliente) {
        this.folio_venta = folio_venta;
        this.id_cliente = id_cliente;
    }

    public Venta(int folio_venta, int id_cliente, String fecha, double total, String nombre_cliente, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono) {
        super(id_cliente, nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
        this.folio_venta = folio_venta;
        this.fecha = fecha;
        this.total = total;
    }

    public int getFolio_venta() { return folio_venta; }
    public void setFolio_venta(int folio_venta) { this.folio_venta = folio_venta; }

        public int getId_cliente() { return id_cliente; }
        public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

        public double getTotal() { return total; }
        public void setTotal(double total) { this.total = total; }
}
