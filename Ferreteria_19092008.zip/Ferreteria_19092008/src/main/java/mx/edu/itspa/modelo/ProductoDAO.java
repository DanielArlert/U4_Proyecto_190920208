package mx.edu.itspa.modelo;

import mx.edu.itspa.general.Producto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List listar(){
        String SELECT_ALL_PRODUCTO = "select * from producto";
            
        List<Producto> lista_producto = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_PRODUCTO);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Producto pdt = new Producto();
                
                pdt.setId_producto(rs.getInt(1));
                pdt.setNombre_producto(rs.getString(2));
                pdt.setPrecio_compra(rs.getInt(3));
                pdt.setPrecio_venta(rs.getInt(4));
                pdt.setMarca(rs.getString(5));
                pdt.setStock(rs.getInt(6));
                pdt.setMedidas(rs.getString(7));
                
                lista_producto.add(pdt);
            }            
        } catch (Exception e){
            
        }
        return lista_producto;
    }  
    
    
    public int Agregar(Producto p){
        String INSERT_PRODUCTO = "insert into producto(nombre_producto, precio_compra, "
                + "precio_venta, marca, stock, medidas) values(?, ?, ?, ?, ?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_PRODUCTO);
            
            ps.setString(1, p.getNombre_producto());
            ps.setInt(2, p.getPrecio_compra());
            ps.setInt(3, p.getPrecio_venta());
            ps.setString(4, p.getMarca());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getMedidas());

                ps.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public int Actualizar(Producto p){
        String UPDATE_PRODUCTO = "update producto set nombre_producto=?, precio_compra=?, "
                + "precio_venta=?, marca=?, stock=?, medidas=? where id_producto=?";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(UPDATE_PRODUCTO);
            
            ps.setString(1, p.getNombre_producto());
            ps.setInt(2, p.getPrecio_compra());
            ps.setInt(3, p.getPrecio_venta());
            ps.setString(4, p.getMarca());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getMedidas());
            ps.setInt(7, p.getId_producto());

                ps.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public void Eliminar(int id_producto){
        String DELETE_PRODUCTO = "delete from producto where id_producto="+id_producto;
                
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement preparedStatement = connection.prepareStatement(DELETE_PRODUCTO);
            
            preparedStatement.executeUpdate();
                
        } catch(Exception e){ }
        
    }
    
    
    public Producto ListarPorId(int id_producto){
        String SELECT_PRODUCTO_ID = "select * from producto where id_producto="+id_producto;
        
        Producto pdt = new Producto();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_PRODUCTO_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){ 
                    pdt.setNombre_producto(rs.getString(2));
                    pdt.setPrecio_compra(rs.getInt(3));
                    pdt.setPrecio_venta(rs.getInt(4));
                    pdt.setMarca(rs.getString(5));
                    pdt.setStock(rs.getInt(6));
                    pdt.setMedidas(rs.getString(7));
                ps.executeUpdate();
                }
                
        } catch(Exception e){ }
        
        return pdt;
    }
    
    
    public Producto ListarPorIdConId(int id_producto){
        String SELECT_PRODUCTO_ID = "select * from producto where id_producto="+id_producto;
        
        Producto pdt = new Producto();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_PRODUCTO_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){ 
                    pdt.setId_producto(rs.getInt(1));
                    pdt.setNombre_producto(rs.getString(2));
                    pdt.setPrecio_compra(rs.getInt(3));
                    pdt.setPrecio_venta(rs.getInt(4));
                    pdt.setMarca(rs.getString(5));
                    pdt.setStock(rs.getInt(6));
                    pdt.setMedidas(rs.getString(7));
                ps.executeUpdate();
                }
                
        } catch(Exception e){ }        
       
        return pdt;
    }
    
    
}
