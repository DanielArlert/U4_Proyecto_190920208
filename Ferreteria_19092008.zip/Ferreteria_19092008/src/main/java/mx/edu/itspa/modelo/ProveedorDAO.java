package mx.edu.itspa.modelo;

import mx.edu.itspa.general.Proveedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List listar(){
        String SELECT_ALL_PROVEEDOR = "select * from proveedor";
            
        List<Proveedor> lista_proveedor = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_PROVEEDOR);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Proveedor proo = new Proveedor();
                
                proo.setId_proveedor(rs.getInt(1));
                proo.setNombre_proveedor(rs.getString(2));
                proo.setApellidop_proveedor(rs.getString(3));
                proo.setApellidom_proveedor(rs.getString(4));
                proo.setCorreo(rs.getString(5));
                  
                lista_proveedor.add(proo);
            }            
            
        } catch (Exception e){
            
        }
        return lista_proveedor;
    }
    
    
    public int Agregar(Proveedor p){
        String INSERT_PROVEEDOR = "insert into proveedor(nombre_proveedor, apellidop_proveedor, "
                + "apellidom_proveedor, correo) values(?, ?, ?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_PROVEEDOR);
            
            ps.setString(1, p.getNombre_proveedor());
            ps.setString(2, p.getApellidop_proveedor());
            ps.setString(3, p.getApellidom_proveedor());
            ps.setString(4, p.getCorreo());
            
                ps.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public int Actualizar(Proveedor p){
        String UPDATE_PROVEEDOR = "update proveedor set nombre_proveedor=?, apellidop_proveedor=?, "
                + "apellidom_proveedor=?, correo=? where id_proveedor=?";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(UPDATE_PROVEEDOR);
            
            ps.setString(1, p.getNombre_proveedor());
            ps.setString(2, p.getApellidop_proveedor());
            ps.setString(3, p.getApellidom_proveedor());
            ps.setString(4, p.getCorreo());
            ps.setInt(5, p.getId_proveedor());

                ps.executeUpdate();
                
        } catch(Exception e){ }
            
        return r;
    }
    
    
    public void Eliminar(int id_proveedor){
        String DELETE_PROVEEDOR = "delete from proveedor where id_proveedor="+id_proveedor;
                
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement preparedStatement = connection.prepareStatement(DELETE_PROVEEDOR);
            
            preparedStatement.executeUpdate();
                
        } catch(Exception e){ }
        
    }
    
    
    public Proveedor ListarPorId(int id_proveedor){
        String SELECT_PROVEEDOR_ID = "select * from proveedor where id_proveedor="+id_proveedor;
        
        Proveedor proo = new Proveedor();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_PROVEEDOR_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                
                    proo.setNombre_proveedor(rs.getString(2));
                    proo.setApellidop_proveedor(rs.getString(3));
                    proo.setApellidom_proveedor(rs.getString(4));
                    proo.setCorreo(rs.getString(5));            

                ps.executeUpdate();
                }
                
        } catch(Exception e){ }
        
        return proo;
    }
    
    
    public Proveedor ListarPorIdConId(int id_proveedor){
        String SELECT_PROVEEDOR_ID = "select * from proveedor where id_proveedor="+id_proveedor;
        
        Proveedor proo = new Proveedor();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_PROVEEDOR_ID);
            ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                    proo.setId_proveedor(rs.getInt(1));
                    proo.setNombre_proveedor(rs.getString(2));
                    proo.setApellidop_proveedor(rs.getString(3));
                    proo.setApellidom_proveedor(rs.getString(4));
                    proo.setCorreo(rs.getString(5));            

                ps.executeUpdate();
                }
                
        } catch(Exception e){ }
        
        return proo;
    }
    
}
