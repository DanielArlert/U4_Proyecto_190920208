package mx.edu.itspa.general;

public class Usuario extends Rol{
    protected int id_usuario;
    protected String usuario;
    protected String clave;
    protected int id_rol;

    public Usuario() { }

    public Usuario(int id_rol, String nombre_rol, int id_usuario, String usuario, String clave) {
        super(id_rol, nombre_rol);
        this.id_usuario = id_usuario;
        this.usuario = usuario;
        this.clave = clave;
    }

    public int getId_usuario() { return id_usuario; }
    public void setId_usuario(int id_producto) { this.id_usuario = id_producto; }

        public String getUsuario() { return usuario; }
        public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

        public int getId_rol() { return id_rol; }
        public void setId_rol(int id_rol) { this.id_rol = id_rol; }
}
