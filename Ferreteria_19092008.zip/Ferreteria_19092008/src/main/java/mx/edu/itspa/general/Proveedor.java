package mx.edu.itspa.general;

public class Proveedor {
    protected int id_proveedor;
    protected String nombre_proveedor;
    protected String apellidop_proveedor;
    protected String apellidom_proveedor;
    protected String correo;

    public Proveedor() {    }

    public Proveedor(   int id_proveedor, String nombre_proveedor, 
                        String apellidop_proveedor, String apellidom_proveedor, String correo) {
        this.id_proveedor = id_proveedor;
        this.nombre_proveedor = nombre_proveedor;
        this.apellidop_proveedor = apellidop_proveedor;
        this.apellidom_proveedor = apellidom_proveedor;
        this.correo = correo;
    }

    public int getId_proveedor() { return id_proveedor; }
    public void setId_proveedor(int id_proveedor) { this.id_proveedor = id_proveedor; }

        public String getNombre_proveedor() { return nombre_proveedor; }
        public void setNombre_proveedor(String nombre_proveedor) { this.nombre_proveedor = nombre_proveedor; }

    public String getApellidop_proveedor() { return apellidop_proveedor; }
    public void setApellidop_proveedor(String apellidop_proveedor) { this.apellidop_proveedor = apellidop_proveedor; }

        public String getApellidom_proveedor() { return apellidom_proveedor; }
        public void setApellidom_proveedor(String apellidom_proveedor) { this.apellidom_proveedor = apellidom_proveedor; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}
