package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Venta;

public class VentaDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List ListarFacturaVenta(){
        String SELECT_ALL_VENTA = "select * from FacturaVentas";
            
        List<Venta> lista_venta = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_VENTA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Venta venta = new Venta();
                
                venta.setFolio_venta(rs.getInt(1));
                venta.setNombre_cliente(rs.getString(2));
                venta.setApellidop_cliente(rs.getString(3));
                venta.setApellidom_cliente(rs.getString(4));
                venta.setTotal(rs.getDouble(5));
                venta.setFecha(rs.getString(6));
                  
                lista_venta.add(venta);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_venta;
    }
    
    
    public int ProximaFacturaVenta(){
        String SELECT_SIG_VENTA = "select * from FolioVentaSiguiente";
            
        Venta venta = new Venta();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_SIG_VENTA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                venta.setFolio_venta(rs.getInt(1));

                ps.executeUpdate();                
            }            
            
        } catch (Exception e){ }
        
        return venta.getFolio_venta();
    }
    
    
    public Venta ListarVentasPorId(int folio_venta){
        String SELECT_FOLIO_ID = "select * from FacturaVentas where folio_venta="+folio_venta;
        
        Venta venta = new Venta();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_FOLIO_ID);
            ResultSet rs = ps.executeQuery();
                
            while(rs.next()){
                venta.setFolio_venta(rs.getInt(1));
                venta.setId_cliente(rs.getInt(2));
                venta.setNombre_cliente(rs.getString(3));
                venta.setApellidop_cliente(rs.getString(4));
                venta.setApellidom_cliente(rs.getString(5));
                venta.setTotal(rs.getDouble(6));
                venta.setFecha(rs.getString(7));   
                
                    ps.executeUpdate();
            }
                
        } catch(Exception e){ }
        
        return venta;
    }
    
    
    public List ListarVentas(){
        String SELECT_FV = "select * from FacturaVentas";
            
        List<Venta> lista_venta = new ArrayList();
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_FV);
            ResultSet rs = ps.executeQuery();
                
            while(rs.next()){
                Venta venta = new Venta();
                
                venta.setFolio_venta(rs.getInt(1));
                venta.setId_cliente(rs.getInt(2));
                venta.setNombre_cliente(rs.getString(3));
                venta.setApellidop_cliente(rs.getString(4));
                venta.setApellidom_cliente(rs.getString(5));
                venta.setTotal(rs.getDouble(6));
                venta.setFecha(rs.getString(7)); 
                
                    lista_venta.add(venta);
            }
                
        } catch(Exception e){ }
        
        return lista_venta;
    }
    
    
    public int Agregar(Venta venta){
        String INSERT_VENTA = "insert into venta(folio_venta, id_cliente) values(?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_VENTA);
            
            ps.setInt(1, venta.getFolio_venta());
            ps.setInt(2, venta.getId_cliente());

            ps.executeUpdate();
                
        } catch(SQLException e){ }
        
        return r;
    }
    
}
