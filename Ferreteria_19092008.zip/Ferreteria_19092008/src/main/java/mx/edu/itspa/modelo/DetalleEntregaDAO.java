package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.DetalleEntrega;

public class DetalleEntregaDAO {
    Conexion connect = new Conexion();
    int r;
    
    
    public List ListarDetalleFacturaEntrega(){
        String SELECT_ALL_ENTREGA = "select * from DetalleFacturaEntregas";
            
        List<DetalleEntrega> lista_dentrega = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_ALL_ENTREGA);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                DetalleEntrega dentrega = new DetalleEntrega();
                
                dentrega.setFolio_entrega(rs.getInt(1));
                dentrega.setNombre_producto(rs.getString(2));
                dentrega.setCantidad_pieza(rs.getInt(3));
                dentrega.setTotal_pieza(rs.getDouble(4));
                dentrega.setFecha(rs.getString(5));
                  
                lista_dentrega.add(dentrega);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_dentrega;
    }
    
    
    public List ListarPorId(int folio_entrega){
        String SELECT_DETALLE = "select * from DetalleFacturaEntregas where folio_entrega="+folio_entrega;
            
        List<DetalleEntrega> lista_dentrega = new ArrayList();
        
        try{
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(SELECT_DETALLE);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                DetalleEntrega dentrega = new DetalleEntrega();
                
                dentrega.setFolio_entrega(rs.getInt(1));
                dentrega.setNombre_producto(rs.getString(2));
                dentrega.setCantidad_pieza(rs.getInt(3));
                dentrega.setTotal_pieza(rs.getDouble(4));
                dentrega.setFecha(rs.getString(5));
                  
                lista_dentrega.add(dentrega);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_dentrega;
    }
    
    
    public int Agregar(DetalleEntrega dentrega){
        String INSERT_DETALLE_ENTREGA = "insert into detalle_entrega(folio_entrega, id_producto, cantidad_pieza) values(?, ?, ?)";
        
        try{ 
            Connection connection = connect.Conectar();
            PreparedStatement ps = connection.prepareStatement(INSERT_DETALLE_ENTREGA);
            
            ps.setInt(1, dentrega.getFolio_entrega());
            ps.setInt(2, dentrega.getId_producto());
            ps.setInt(3, dentrega.getCantidad_pieza());

            ps.executeUpdate();
                
        } catch(SQLException e){ }
        
        return r;
    }
    
}
